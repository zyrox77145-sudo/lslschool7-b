# LSL School — Minimal 3D Neon Showcase & 7-B Class Schedule

A streamlined, 100% English 3D neon **"LSL School"** showcase featuring a single gentle levitating Cyan & Magenta sculpture, a briskly descending **"7 - B Class Schedule"** button floating cleanly above the logo, and an interactive **Monday–Sunday** 8-period editable timetable drawer.

## User Review & Critical Decisions

> [!IMPORTANT]
> Your Phase 1 preferences and updated instructions are locked into the plan below. Please review and approve to update the application.

- **Confirmed Decision 1 — Minimal Gentle Floating Scene**: All color palette pickers, language toggles, flight-mode switches, and the bottom control dock are removed. **"LSL School"** remains suspended in dark obsidian space in its signature Cyan & Magenta neon finish with gentle levitation, ambient particles, and 360° mouse orbit.
- **Confirmed Decision 2 — Animated Top-Center `"7 - B Class Schedule"` Button**: A crisp, clickable **"7 - B Class Schedule"** button glides swiftly down from the top edge (`transform` + `opacity`) to settle directly above the **"LSL School"** neon centerpiece.
- **Confirmed Decision 3 — Monday Pre-Filled, Tuesday–Sunday Empty & Editable**:
  - **Monday (Periods 1–8)**: 1. Mathematics, 2. Mathematics, 3. IT, 4. IT, 5. Geography, 6. Physics, 7. Foreign Language, 8. Foreign Language.
  - **Tuesday–Sunday**: Start empty and ready for user input via inline editing.
- **Confirmed Decision 4 — Day Tabs + 8 Periods + Editable Time Slots (All English)**: Opening the schedule reveals `Monday`–`Sunday` day tabs, 8 numbered period rows with editable start/end times (e.g. `08:30 – 09:15`) and editable subject inputs saved locally in `localStorage`.

---

## 1. Overview & Core Concept

- **What It Does**: Combines a clean, distraction-free 3D neon **"LSL School"** centerpiece with a practical, fast-access **7-B Class Schedule** viewer and editor in English.
- **Target Audience**: Students and teachers of **Class 7-B** at LSL School who want an atmospheric visual display paired with immediate one-click access to their weekly timetable.
- **Key Value**: Eliminates visual control clutter so the floating neon emblem and the **"7 - B Class Schedule"** action share undisputed focus, while keeping Monday–Sunday schedules editable and persistent across browser reloads.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Brisk Floating Entrance**: On load, the 3D **"LSL School"** neon sign ignites with a brief glow and hovers gently in the center, while the **"7 - B Class Schedule"** button glides smoothly down from the top edge into position directly above the logo (`~550ms` cubic-bezier settling curve, plus subtle floating poise).
2. **Minimal 3D Interaction**: Users can drag anywhere on the canvas to orbit around **"LSL School"**, scroll to zoom, tilt via gentle pointer parallax, or click directly on the neon sign for an electrical surge pulse—with zero bottom control bars blocking the viewport.
3. **Opening the 7-B Schedule**: Clicking **"7 - B Class Schedule"** opens a focused, high-contrast obsidian schedule panel centered over the darkened stage (`Escape` or close button dismisses it cleanly).
4. **Browsing & Editing Monday–Sunday**:
   - **Day Navigation**: Horizontal single-line tabs for `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`, `Sunday` (each showing a subtle count of scheduled classes).
   - **Monday**: Pre-loaded with all 8 requested English subjects (`Mathematics` ×2, `IT` ×2, `Geography`, `Physics`, `Foreign Language` ×2).
   - **Tuesday–Sunday & Inline Editing**: Every period row (`1` through `8`) lets the user click to edit or type a **Subject** and adjust its **Time Slot** (`tabular-nums`, e.g. `08:30 - 09:15`), with clear `Save` / `Clear` actions and automatic persistence to `localStorage`.

### Visual Identity & Theme
- **Aesthetic Direction**: Clean dark-studio spatial centerpiece paired with structured, legible timetable typography.
- **Color Palette & Mood**:
  - `--background`: Deep obsidian (`#05070D`) with matching exponential fog and subtle glowing floor grid.
  - `--primary`: Electric Cyan (`#22D3EE`) for **"LSL"**, active schedule accents, and button highlights.
  - `--accent`: Vivid Magenta (`#EC4899`) for **"School"** and subtle secondary rim highlights.
  - `--surface`: Solid dark slate (`rgba(11, 15, 26, 0.94)`) with crisp hairline borders (`rgba(255, 255, 255, 0.12)`)—avoiding CSS `backdrop-filter` over WebGL to preserve frame pacing.
- **Typography & Hierarchy**:
  - *Display*: `Outfit` for `"7 - B Class Schedule"` header and day titles.
  - *Body & Controls*: `Plus Jakarta Sans` for crisp, everyday English labels and subject names.
  - *Schedule Times & Period Numbers*: `JetBrains Mono` with `tabular-nums` so `08:30 – 09:15` aligns cleanly across all 8 rows.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Strip Bottom Control Dock & Color Pickers**
  - *Chosen Approach*: Lock the 3D scene to its signature Cyan & Magenta palette and gentle levitation physics, removing all sliders, color swatches, flight-mode switches, and language toggles.
  - *Why*: Directly fulfills the request for a clean, single gentle-floating neon scene without distracting UI chrome.

- **Decision 2 — Local Browser Persistence (`localStorage`) for Schedule Edits**
  - *Chosen Approach*: Initialize Monday with the exact 8 requested classes and Tuesday–Sunday with empty editable slots, persisting user edits in `localStorage` with a safe JSON parser and a one-click `"Reset Default"` option for Monday.
  - *Why*: Instantaneous save/load with zero login friction, while guaranteeing Monday's exact curriculum is always available.

- **Decision 3 — Compositor-Only Entrance Animation**
  - *Chosen Approach*: Animate the `"7 - B Class Schedule"` button's downward float using CSS/Motion `transform` and `opacity` only (`cubic-bezier(0.16, 1, 0.3, 1)`), respecting `prefers-reduced-motion`.
  - *Why*: Smooth 60fps glide over the active WebGL canvas without triggering layout reflows.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### System & Component Architecture

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                             Root Viewport                               │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │               Isolated Three.js WebGL Canvas Mount                │  │
│  │  • LSL School 3D Neon Sculpture (Fixed Cyan & Magenta, Gentle)    │  │
│  │  • Ambient Luminous Particles & Subtle Horizon Grid               │  │
│  │  • OrbitControls + Pointer Parallax + Click-to-Surge              │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │        Top-Center Floating Trigger (Brisk Top-Down Glide)         │  │
│  │                [  7 - B Class Schedule  ]                         │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                  │                                      │
│                             (onClick)                                   │
│                                  ▼                                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │             7-B Class Schedule Modal (100% English)               │  │
│  │  • Day Tabs: Mon | Tue | Wed | Thu | Fri | Sat | Sun              │  │
│  │  • 8 Period Rows (Period # · Time Slot · Subject · Edit/Clear)    │  │
│  │  • LocalStorage Sync + Reset Monday Default                       │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Interactive State Mapping
- **Schedule Store (`Record<DayOfWeek, PeriodEntry[]>`)**:
  - `DayOfWeek`: `'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday'`.
  - Each day contains 8 `PeriodEntry` objects (`period: 1..8`, `time: string`, `subject: string`).
  - `Monday` defaults to: `1. Mathematics`, `2. Mathematics`, `3. IT`, `4. IT`, `5. Geography`, `6. Physics`, `7. Foreign Language`, `8. Foreign Language`.
  - `Tuesday`–`Sunday` default to `subject: ''` with standard period times (`08:30 - 09:15` through `15:20 - 16:05`).
- **Interactive Handlers**:
  - Clicking **"7 - B Class Schedule"** opens the timetable modal focused on `Monday`.
  - Clicking any day tab switches the active 8-period list cleanly.
  - Clicking any period's edit control (or empty slot) opens inline `subject` and `time` inputs (`Enter` saves, `Escape` cancels), immediately updating state and `localStorage`.
  - Clicking `Clear` empties a single period slot; clicking `Restore Monday` restores Monday's 8 prescribed classes if modified.
